package CC;

public class RocketSystem implements IRocketSystemBase{
	int sys_nozzle;
	int sys_pressure;
	String sys_message;
	@Override
	public void ignite(int nozzle, int pressure) {
		// TODO Auto-generated method stub
		this.sys_nozzle = nozzle;
		this.sys_pressure = pressure;
		String query = "IGNITE "+ Integer.toString(this.sys_nozzle) + " " + Integer.toString(this.sys_pressure)+ " " + " AT ";
		System.out.print(query);
	} 
 
	@Override
	public void shutoff(int nozzle) {
		// TODO Auto-generated method stub
		this.sys_nozzle = nozzle;
		String query = "SHUTOFF "+ Integer.toString(this.sys_nozzle) + " AT ";
		System.out.print(query);
	}
 
	@Override
	public void log(String message) {
		// TODO Auto-generated method stub
		this.sys_message = message;
	}

}
