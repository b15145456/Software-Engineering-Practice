package CC;

public interface IRocketSystemBase {
	public void ignite(int nozzle, int pressure);

	public void shutoff(int nozzle);

	public void log(String message);
	
}
