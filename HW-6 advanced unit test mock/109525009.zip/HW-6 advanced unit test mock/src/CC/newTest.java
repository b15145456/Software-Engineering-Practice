package CC;
import junit.framework.TestCase;
import org.junit.Assert;

public class newTest extends TestCase {
		RocketSystem rocket = new RocketSystem() ;
		RocketController RC = new RocketController();
	public void testSystem() throws Exception {
		RC.setUpRocketSystem(rocket);
		int time = 11; 
		for(int i = 0; i <= time; i++) {
			if (i == 0) {
				RC.fireUp("IGNITE 0 1000 AT "+ i +" \n");//rocket.ignite(0, 1000);
				System.out.print(i+" \n");
				Assert.assertEquals(rocket.sys_nozzle,0);
				Assert.assertEquals(rocket.sys_pressure,1000);
			}else if(i == 2) {
				RC.fireUp("IGNITE 1 500 AT "+ i +" \n");
				System.out.print(i+" \n");
				Assert.assertEquals(rocket.sys_nozzle,1);
				Assert.assertEquals(rocket.sys_pressure,500);
			}else if(i == 5) { 
				RC.fireUp("SHUTOFF 0 AT "+ i +" \n");
				System.out.print(i+" \n");
				Assert.assertEquals(rocket.sys_nozzle,0);
			}else if(i == 6) {
				RC.fireUp("SHUTOFF 1 AT "+ i +" \n"); 
				System.out.print(i+" \n");
				Assert.assertEquals(rocket.sys_nozzle,1);
				 
			//Test exception branches
			}else if(i == 3) {
				RC.fireUp("IGNITE 1 500 AT 2 "+ i +" \n");
				System.out.print(i+" \n");
				Assert.assertEquals("ERROR_QUREY_FORMAT",rocket.sys_message);
			}else if(i == 7) {
				RC.fireUp("SHUTOFF 1 AT 1 "+ i +" \n"); 
				System.out.print(i+" \n");
				Assert.assertEquals("ERROR_QUREY_FORMAT",rocket.sys_message);

			}else if(i == 8) {
				RC.fireUp("IGNITE 1 AT 12 "+ i +" \n"); 
				System.out.print(i+" \n");
				Assert.assertEquals("ERROR_QUREY_FORMAT",rocket.sys_message);

			}else if(i == 9) {
				RC.fireUp("SHUTOFF 9 A "+ i +" \n"); 
				System.out.print(i+" \n");
				Assert.assertEquals("ERROR_QUREY_FORMAT",rocket.sys_message);

			}else if(i == 10) {
				RC.fireUp("IGNIT 1 AT 12 "+ i +" \n"); 
				System.out.print(i+" \n");
				Assert.assertEquals("ERROR_QUREY_FORMAT",rocket.sys_message);

			}else if(i == 11) {
				RC.fireUp(" "); 
				System.out.print(i+" \n");
				Assert.assertEquals("Index 0 out of bounds for length 0",rocket.sys_message);

			}
			Thread.sleep(1000);
        }
		
	}
//	@Test
//	public void testFireup() throws Exception {
//		Scanner scanner = new Scanner(System.in);
//	    String nextLine = scanner.nextLine();
//	    String sum ="";
//		while (nextLine != null && !nextLine.equals("")) {
//			sum += nextLine;
//		    System.out.println(sum);
//		    nextLine = scanner.nextLine();
//		}
//		RC.fireUp(sum);
//		Assert.AreEqual("Filename too short: abc.txt", rocket.LastError);	
//	}
}