#include <stdio.h>
#include "awk_sem.h"

main() {
    int i = 0 ;
    // *** please insert proper semaphore initialization here
    int semid1 ;
    int semid2 ;
    int semid3 ;
    //int semid4 ;

    semid1 = create_sem(".",'Sam1',1);
    semid2 = create_sem(".",'Sam2',0);
    semid3 = create_sem(".",'Sam3',0);
    //semid4 = create_sem(".",'Sam4',1);

    do {    
       P(semid1);
       printf("P1111111111 is here\n"); i++;
       V(semid2); 
       
    }  while (i < 100) ;
}