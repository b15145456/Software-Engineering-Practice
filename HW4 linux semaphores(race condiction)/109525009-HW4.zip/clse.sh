ipcs -s | grep 'ulun' | awk ' { print $2 } ' | xargs ipcrm sem

gcc -o p1 p1.c sem.c
gcc -o p2 p2.c sem.c
gcc -o p3 p3.c sem.c