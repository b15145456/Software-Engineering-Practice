#include <stdio.h>
#include "awk_sem.h"

main() {
    int i = 0 ;
    int semid1 ;
    int semid2 ;
    int semid3 ;
    //int semid4 ;

    semid1 = get_sem(".",'Sam1');  
    semid2 = get_sem(".",'Sam2');
    semid3 = get_sem(".",'Sam3');
    //semid4 = get_sem(".",'Sam4');

    // *** please insert proper semaphore initialization here
    do {
       P(semid3);
       printf("P3333333 is here\n");i++ ;
       V(semid2);
       // *** this is where you should place semaphore
       
    }  while (i< 200);
}